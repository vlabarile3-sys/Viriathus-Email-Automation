﻿/**
* ==========================================
* VIRIATHUS - Backend Architect: Hefestus
* Code.gs - Agnostic Engine, Explicit Thread Linking V4.3 (2026 Enterprise Patched)
* HOTFIX: Memory Payload Limit Bypass & Audit Lock Optimization
* ==========================================
*/

/**
* V4.3 PATCH: Configurazione Dinamica
* Estrae le proprietà di script; il placeholder deve essere sostituito prima dell'uso.
*/
const getDynamicSettings = () => {
const props = PropertiesService.getScriptProperties();
return {
mainSpreadsheetId: props.getProperty('VIRIATHUS_MAIN_DB') || 'YOUR_SPREADSHEET_ID',
templateTabName: 'Template Email',
auditTabName: 'Audit_Log'
};
};

const GLOBAL_SETTINGS = getDynamicSettings();

const DEFAULT_TEMPLATES = {
"Offline Day Demo": {
targetWorkflow: 'Demo_Agents',
ccEmails: 'manager1@example.com, manager2@example.com',
emailSubject: '{{AGENT_ID}} || Offline Day || {{DATE}}',
driveFileId: '',
destinationFolderId: '',
emailBody: 'Hi Team,<br><br>This is to inform you that <strong>{{AGENT_NAME}}</strong> will be in Offline Day mode on <strong>{{DATE}}</strong>.<br><br>The agent will recap all the updates that we had during these days.<br>You can access the personalized plan by clicking here: <a href="{{FILE_URL}}">Offline Day File</a>.<br><br>In the afternoon, the agent will have shadowing / reverse shadowing with a colleague.<br><br>Please let me know if you have any questions or doubts.<br><br>Regards,'
}
};

/**
* Inizializza la Web App (UX 2026 Ready)
*/
function doGet(e) {
return HtmlService.createTemplateFromFile('Index')
.evaluate()
.setTitle('Viriathus - Corporate Engine 2026')
.setFaviconUrl('https://i.postimg.cc/nLxkRVJp/preview.png')
.addMetaTag('viewport', 'width=device-width, initial-scale=1')
.setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
* Include file HTML/CSS/JS secondari
*/
function include(filename) {
return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

/**
* Recupera o crea il Foglio Database dei Template
*/
function getTemplateSheet() {
const ss = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId);
let sheet = ss.getSheetByName(GLOBAL_SETTINGS.templateTabName);

if (!sheet) {
sheet = ss.insertSheet(GLOBAL_SETTINGS.templateTabName);
sheet.getRange("A1:B1").setValues([["Last Update", "Templates JSON Database"]])
.setBackground("#141821").setFontColor("#d4af37").setFontWeight("bold");
sheet.setColumnWidth(2, 800);
}
return sheet;
}

/**
* Recupera o crea il Foglio di Audit Log
*/
function getAuditSheet() {
const ss = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId);
let sheet = ss.getSheetByName(GLOBAL_SETTINGS.auditTabName);
let needsSetup = false;

if (!sheet) {
sheet = ss.insertSheet(GLOBAL_SETTINGS.auditTabName);
needsSetup = true;
} else if (sheet.getRange("A1").getValue() !== "Timestamp" || sheet.getRange("E1").getValue() !== "Action Taken") {
sheet.clear();
needsSetup = true;
}

if (needsSetup) {
sheet.getRange("A1:E1").setValues([["Timestamp", "Agent Name", "Workflow", "Target Date", "Action Taken"]])
.setBackground("#141821").setFontColor("#d4af37").setFontWeight("bold")
.setHorizontalAlignment("center");
sheet.setFrozenRows(1);
sheet.setColumnWidth(1, 160);
sheet.setColumnWidth(2, 200);
sheet.setColumnWidth(3, 150);
sheet.setColumnWidth(4, 120);
sheet.setColumnWidth(5, 250);
}
return sheet;
}

/**
* Recupera lo storico delle operazioni di Audit per il Frontend
*/
function getAuditHistory() {
try {
const sheet = getAuditSheet();
const lastRow = sheet.getLastRow();
if (lastRow < 2) return [];

const startRow = Math.max(2, lastRow - 99);
const numRows = lastRow - startRow + 1;
const data = sheet.getRange(startRow, 1, numRows, 5).getDisplayValues();
return data.reverse().map(row => ({
timestamp: row[0],
agentName: row[1],
workflow: row[2],
targetDate: row[3],
action: row[4]
}));
} catch (e) {
return [];
}
}

/**
* V4.3 PATCH: Recupera i template. Bypass 9KB limit di ScriptProperties.
* Utilizza CacheService (100KB) e lettura diretta del foglio.
*/
function getTemplates() {
try {
const cache = CacheService.getScriptCache();
let saved = cache.get('VIRIATHUS_TEMPLATES_V43');
if (!saved) {
const sheet = getTemplateSheet();
saved = sheet.getRange("B2").getValue();
if (saved && String(saved).length < 100000) {
cache.put('VIRIATHUS_TEMPLATES_V43', saved, 21600);
}
}
return saved ? JSON.parse(saved) : DEFAULT_TEMPLATES;
} catch (e) {
console.error("Cache Read Error:", e);
return DEFAULT_TEMPLATES;
}
}

/**
* V4.3 PATCH: Sincronizza il Database JSON su Sheet e aggiorna la Cache.
*/
function syncTemplates(templates) {
const jsonString = JSON.stringify(templates);
const sheet = getTemplateSheet();
sheet.getRange("A2:B2").setValues([[new Date().toISOString(), jsonString]]);
const cache = CacheService.getScriptCache();
if (jsonString.length < 100000) {
cache.put('VIRIATHUS_TEMPLATES_V43', jsonString, 21600);
} else {
cache.remove('VIRIATHUS_TEMPLATES_V43');
}
}

/**
* Salva un nuovo template o aggiorna esistente
*/
function saveTemplate(templateName, templateData) {
const lock = LockService.getScriptLock();
if (!lock.tryLock(15000)) return { success: false, error: "Database busy. Please try again." };

try {
const cleanName = templateName?.trim();
if (!cleanName) throw new Error("Template name is required.");

delete templateData.requiresTracking;
delete templateData.completionSubject;
delete templateData.threadSearchQuery;

let templates = getTemplates();
templates[cleanName] = templateData;
syncTemplates(templates);
return { success: true, message: 'Template ' + cleanName + ' saved and backed up successfully!', templates: templates };
} catch (e) {
return { success: false, error: e.message };
} finally {
lock.releaseLock();
}
}

/**
* Elimina un template
*/
function deleteTemplate(templateName) {
const lock = LockService.getScriptLock();
if (!lock.tryLock(15000)) return { success: false, error: "Database busy." };

try {
let templates = getTemplates();
if (!templates[templateName]) throw new Error("Template not found.");
delete templates[templateName];
if (Object.keys(templates).length === 0) templates = DEFAULT_TEMPLATES;
syncTemplates(templates);
return { success: true, message: 'Template deleted and backup updated.', templates: templates };
} catch (e) {
return { success: false, error: e.message };
} finally {
lock.releaseLock();
}
}

/**
* Restituisce i dati iniziali per la UI
*/
function getInitialData() {
try {
return { success: true, workflows: getWorkflows(), templates: getTemplates() };
} catch (e) {
return { success: false, error: e.message };
}
}

/**
* Scansiona e restituisce la lista dei Workflows
*/
function getWorkflows() {
try {
const ss = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId);
return ss.getSheets()
.map(sheet => sheet.getName())
.filter(name => name !== GLOBAL_SETTINGS.templateTabName && name !== GLOBAL_SETTINGS.auditTabName);
} catch (e) {
throw new Error('Could not load workflows: ' + e.message);
}
}

/**
* Crea una nuova scheda Workflow
*/
function createWorkflow(workflowName) {
const lock = LockService.getScriptLock();
if (!lock.tryLock(30000)) return { success: false, error: "Database timeout." };

try {
const cleanName = workflowName?.trim();
if (!cleanName) throw new Error("Workflow name cannot be empty.");
const ss = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId);
if (ss.getSheetByName(cleanName)) return { success: false, message: 'Workflow ' + cleanName + ' already exists.' };
const newSheet = ss.insertSheet(cleanName);
newSheet.getRange('A1:D2').setBackground('#141821').setFontColor('#d4af37').setFontWeight('bold');
newSheet.getRange('A2:D2').setValues([['Nº', 'Ldap', 'Name', 'Gmail']]);
newSheet.setFrozenRows(2);
return { success: true, message: 'Workflow ' + cleanName + ' created successfully.', workflows: getWorkflows() };
} catch (e) {
return { success: false, error: e.message };
} finally {
lock.releaseLock();
}
}

/**
* Recupera Agenti da uno specifico Workflow
*/
function getAgentsByWorkflow(workflowName) {
if(!workflowName) return [];
const cacheKey = 'VIRIATHUS_AGENTS_' + workflowName.replace(/\s+/g, '_');
const cache = CacheService.getScriptCache();
const cached = cache.get(cacheKey);
if (cached) return JSON.parse(cached);
try {
const sheet = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId).getSheetByName(workflowName);
if (!sheet) return [];
const lastRow = sheet.getLastRow();
if (lastRow < 3) return [];
const agents = sheet.getRange('B3:D' + lastRow).getValues()
.map(([id, name, email]) => {
if (!id || !String(id).trim() || !email || !String(email).trim()) return null;
return { id: String(id).trim(), name: name ? String(name).trim() : String(id).trim(), email: String(email).trim() };
}).filter(Boolean);
cache.put(cacheKey, JSON.stringify(agents), 30);
return agents;
} catch (e) {
throw new Error('Error loading agents: ' + e.message);
}
}

/**
* Inietta agenti massivamente nel Workflow
*/
function addAgentsBulk(agentsString, workflowName) {
if (!workflowName) throw new Error("Please select a workflow.");
const rawLdaps = (agentsString || '').split(',').map(s => s.trim()).filter(Boolean);
if (!rawLdaps.length) throw new Error("No valid LDAP provided.");

const lock = LockService.getScriptLock();
if (!lock.tryLock(30000)) throw new Error("System is busy. Please try again.");

try {
const sheet = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId).getSheetByName(workflowName);
if (!sheet) throw new Error('Workflow ' + workflowName + ' not found.');
const existingLdaps = new Set(sheet.getRange('B1:B' + Math.max(sheet.getLastRow(), 1)).getValues().flat().map(v => String(v).trim()));
const toAdd = rawLdaps.filter(ldap => !existingLdaps.has(ldap));
if (toAdd.length > 0) {
const startRow = Math.max(sheet.getLastRow() + 1, 3);
const rows = toAdd.map(ldap => [ldap, ldap, ldap + '@example.com']);
sheet.getRange(startRow, 2, rows.length, 3).setValues(rows);
CacheService.getScriptCache().remove('VIRIATHUS_AGENTS_' + workflowName.replace(/\s+/g, '_'));
}
return { success: true, message: 'Added ' + toAdd.length + ' agent(s).' };
} finally {
lock.releaseLock();
}
}

/**
* Cancella in batch N agenti
*/
function deleteAgentsBatch(agentLdaps, workflowName) {
if (!workflowName || !agentLdaps?.length) throw new Error("Missing data.");
const lock = LockService.getScriptLock();
if (!lock.tryLock(30000)) throw new Error("System is busy.");
try {
const sheet = SpreadsheetApp.openById(GLOBAL_SETTINGS.mainSpreadsheetId).getSheetByName(workflowName);
if (!sheet) throw new Error("Workflow not found.");
const values = sheet.getRange('B1:B' + sheet.getLastRow()).getValues().flat().map(v => String(v).trim());
let deletedCount = 0;
for (let i = values.length - 1; i >= 0; i--) {
if (agentLdaps.includes(values[i])) {
sheet.deleteRow(i + 1);
deletedCount++;
}
}
if (deletedCount > 0) CacheService.getScriptCache().remove('VIRIATHUS_AGENTS_' + workflowName.replace(/\s+/g, '_'));
return { success: true, message: 'Successfully removed ' + deletedCount + ' agent(s).' };
} finally {
lock.releaseLock();
}
}

/**
* V4.3 PATCH: Registra un'azione nel Data Store di Audit
* Sostituito appendRow() con setValues() per eliminare overhead del lock API.
*/
function logAuditEntry(agentName, workflowName, targetDate, actionTaken) {
const lock = LockService.getScriptLock();
if (!lock.tryLock(10000)) return;
try {
const sheet = getAuditSheet();
const timestamp = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "yyyy-MM-dd HH:mm:ss");
const nextRow = Math.max(sheet.getLastRow() + 1, 2);
sheet.getRange(nextRow, 1, 1, 5).setValues([[timestamp, agentName, workflowName, targetDate, actionTaken]]);
} catch (e) {
console.error("Audit Write Failure:", e);
} finally {
lock.releaseLock();
}
}

/**
* RPC Endpoint: Recupera solo i thread strettamente pertinenti.
*/
function fetchAgentThreadsForWizard(workflowName, agentIds) {
const results = {};
try {
const agents = getAgentsByWorkflow(workflowName);
agentIds.forEach(id => {
const agent = agents.find(a => a.id === id);
if (agent) {
const searchQuery = `subject:"${agent.id}" (in:inbox OR in:sent)`;
const threads = GmailApp.search(searchQuery, 0, 10);
results[id] = threads.map(t => {
return {
id: t.getId(),
subject: t.getFirstMessageSubject() || "No Subject",
date: Utilities.formatDate(t.getLastMessageDate(), Session.getScriptTimeZone(), "dd MMM HH:mm")
};
});
} else {
results[id] = [];
}
});
return { success: true, threadsMap: results };
} catch (e) {
return { success: false, error: e.message };
}
}

/**
* Funzione sicura per la rimozione controllata del CSS senza distruggere l'HTML
*/
function sanitizeHtmlStyles(htmlString) {
if (!htmlString) return "";
return htmlString.replace(/style\s*=\s*["']([^"']*)["']/gi, (match, styles) => {
let cleanStyles = styles
.replace(/(?:background-color|background)\s*:[^;]+;?/gi, '')
.replace(/color\s*:\s*(?:#e0e0e0|#fff|#ffffff|rgb\(224,\s*224,\s*224\));?/gi, 'color: #333333;');
return `style="${cleanStyles}"`;
});
}

/**
* Batch Engine V4.3: Generazione email, Explicit Thread Linking e Gestione Errori Drive v3
*/
function generateSingleDraft(workflowName, agentId, dateValue, customEmailData, explicitThreadId) {
try {
const agents = getAgentsByWorkflow(workflowName);
const selectedAgent = agents.find(a => a.id === agentId);
if (!selectedAgent) throw new Error("Agent not found in database.");

const fileIdToCopy = customEmailData.driveFileId?.trim();
const destFolderId = customEmailData.destinationFolderId?.trim();
const requiresFile = !!fileIdToCopy;
const date = new Date(dateValue);
const formattedDate = Utilities.formatDate(date, Session.getScriptTimeZone(), 'yyyy/MM/dd');
const validManagerEmails = customEmailData.ccEmails ?
customEmailData.ccEmails.split(',')
.map(e => e.trim())
.filter(e => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) : [];
let newFileUrl = "";
let newFileId = null;
let permissionErrors = [];

if (requiresFile) {
let templateFile;
try {
templateFile = DriveApp.getFileById(fileIdToCopy);
} catch (err) {
throw new Error("Drive File not found or permission denied.");
}

const mimeType = templateFile.getMimeType();
let newFile = templateFile.makeCopy('File - ' + selectedAgent.name + ' - ' + formattedDate);
if (destFolderId) {
try {
newFile.moveTo(DriveApp.getFolderById(destFolderId));
} catch (moveErr) { console.warn("Move failed: " + moveErr); }
}
newFileUrl = newFile.getUrl();
newFileId = newFile.getId();
if (mimeType === MimeType.GOOGLE_SHEETS) {
const sh = SpreadsheetApp.openById(newFileId);
sh.createTextFinder('{{AGENT_NAME}}').matchCase(false).replaceAllWith(selectedAgent.name);
sh.createTextFinder('{{DATE}}').matchCase(false).replaceAllWith(formattedDate);
sh.createTextFinder('{{AGENT_ID}}').matchCase(false).replaceAllWith(selectedAgent.id);
} else if (mimeType === MimeType.GOOGLE_DOCS) {
const doc = DocumentApp.openById(newFileId);
doc.getBody().replaceText('{{AGENT_NAME}}', selectedAgent.name);
doc.getBody().replaceText('{{DATE}}', formattedDate);
doc.getBody().replaceText('{{AGENT_ID}}', selectedAgent.id);
doc.saveAndClose();
} else if (mimeType === MimeType.GOOGLE_SLIDES) {
const slide = SlidesApp.openById(newFileId);
slide.replaceAllText('{{AGENT_NAME}}', selectedAgent.name);
slide.replaceAllText('{{DATE}}', formattedDate);
slide.replaceAllText('{{AGENT_ID}}', selectedAgent.id);
slide.saveAndClose();
}
const allEmailsToShare = [selectedAgent.email, ...validManagerEmails];
allEmailsToShare.forEach(email => {
try {
Drive.Permissions.create({
'role': 'writer',
'type': 'user',
'emailAddress': email
}, newFileId, {
'sendNotificationEmail': false,
'supportsAllDrives': true
});
} catch (err) {
console.error("Failed to share file " + newFileId + " with " + email + ":", err);
permissionErrors.push(email);
}
});
}
const parseText = function(str) {
if(!str) return "";
return str.replace(/{{AGENT_ID}}/g, selectedAgent.id)
.replace(/{{AGENT_NAME}}/g, selectedAgent.name)
.replace(/{{DATE}}/g, formattedDate)
.replace(/{{FILE_URL}}/g, newFileUrl);
};

const parseBody = function(str) {
let s = parseText(str);
s = sanitizeHtmlStyles(s);
if (newFileUrl) {
s = s.replace(/href=["']{{FILE_URL}}["']/g, 'href="' + newFileUrl + '"');
s = s.replace(/{{FILE_URL}}/g, '<a href="' + newFileUrl + '" target="_blank" style="color: #1155cc; font-weight: bold; text-decoration: underline;">Click Here</a>');
} else {
s = s.replace(/href=["']{{FILE_URL}}["']/g, 'href="#"');
s = s.replace(/{{FILE_URL}}/g, '<em style="color: #999;">No document attached</em>');
}
return s;
};
let draft;
let actionLog = "NEW THREAD DRAFTED";

if (permissionErrors.length > 0) {
actionLog += ` [Warning: Drive share failed for ${permissionErrors.length} users]`;
}

if (explicitThreadId && explicitThreadId !== "NEW") {
try {
const targetThread = GmailApp.getThreadById(explicitThreadId);
if (targetThread) {
const forceAgentIncludeCc = [selectedAgent.email, ...validManagerEmails];
const uniqueCcList = [...new Set(forceAgentIncludeCc)].join(',');

draft = targetThread.createDraftReplyAll('', {
htmlBody: parseBody(customEmailData.emailBody),
cc: uniqueCcList
});
actionLog = permissionErrors.length > 0 ? `EXPLICIT REPLY INJECTED [Warning: Share failed for ${permissionErrors.length}]` : "EXPLICIT REPLY INJECTED";
}
} catch (threadErr) {
console.error("Fallimento nell'aggancio esplicito al thread ID: " + explicitThreadId, threadErr);
}
}

if (!draft) {
draft = GmailApp.createDraft(
selectedAgent.email,
parseText(customEmailData.emailSubject),
'',
{ htmlBody: parseBody(customEmailData.emailBody), cc: validManagerEmails.join(',') }
);
}
logAuditEntry(selectedAgent.name, workflowName, dateValue, actionLog);
return { success: true, url: 'https://mail.google.com/mail/u/0/#drafts?compose=' + draft.getId() };
} catch (e) {
throw new Error('Execution failed for ' + agentId + ': ' + e.message);
}
}
